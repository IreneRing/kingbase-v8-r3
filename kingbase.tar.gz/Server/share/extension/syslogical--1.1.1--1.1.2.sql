SELECT * FROM syslogical.node;
