--CREATE ORA_DATE
--bugId#30455: adapter fanwei about date - date return number
CREATE DOMAIN "SYS_CATALOG"."ORA_DATE" AS TIMESTAMP(0);

CREATE INTERNAL FUNCTION "SYS_CATALOG"."ORACLE_DATE_MI"(ORA_DATE, ORA_DATE)
RETURNS NUMERIC LANGUAGE 'sql'
AS 'SELECT ORA_DATE_MI($1, $2)'
IMMUTABLE
STRICT
PARALLEL
SAFE;

CREATE OPERATOR - (
	LEFTARG = "SYS_CATALOG"."ORA_DATE",
	RIGHTARG = "SYS_CATALOG"."ORA_DATE",
	PROCEDURE = "SYS_CATALOG"."ORACLE_DATE_MI",
	COMMUTATOR = -
);

CREATE INTERNAL FUNCTION "SYS_CATALOG"."ORA_TO_DATE"(TEXT, TEXT)
RETURNS "SYS_CATALOG"."ORA_DATE" LANGUAGE 'sql'
AS 'select cast(to_timestamp_tz($1, $2) as "SYS_CATALOG"."ORA_DATE")'
STABLE
STRICT
PARALLEL SAFE;

/* bugId#30588: adapter fanwei--date data type compatible with oracle */
CREATE INTERNAL FUNCTION "SYS_CATALOG"."ORA_TO_DATE"(TEXT)
RETURNS "SYS_CATALOG"."ORA_DATE" LANGUAGE 'sql'
AS 'select cast(to_timestamp_tz($1, ''YYYY-MM-DD HH24:MI:SS'') as "SYS_CATALOG"."ORA_DATE")'
STABLE
STRICT
PARALLEL SAFE;

create internal function TRUNC(ORA_DATE)
returns ORA_DATE
as 'select cast(date_trunc(''day'', $1) as "SYS_CATALOG"."ORA_DATE")'
LANGUAGE SQL
IMMUTABLE
STRICT;

create internal function TRUNC(ORA_DATE, TEXT)
returns ORA_DATE
as 'select cast(date_trunc($2, $1) as "SYS_CATALOG"."ORA_DATE")'
LANGUAGE SQL
IMMUTABLE
STRICT;

--create functions
--datetime functions
CREATE INTERNAL FUNCTION sys_catalog.TIMESTAMP_ADD_MONTHS(ORA_DATE, NUMERIC)
RETURNS timestamp
AS 'MODULE_PATHNAME','timestamp_add_months'
LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.ADD_MONTHS(ORA_DATE, NUMERIC)
RETURNS ORA_DATE
as 'select cast(TIMESTAMP_ADD_MONTHS($1, $2) as "SYS_CATALOG"."ORA_DATE")'
LANGUAGE SQL
IMMUTABLE
STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.ADD_MONTHS(day timestamptz, val numeric)
--RETURNS timestamp
--AS $$ select ADD_MONTHS(cast($1 as timestamp), val);
--$$ LANGUAGE SQL IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMESTAMP_LAST_DAY(day ORA_DATE)
RETURNS timestamp
AS 'MODULE_PATHNAME','timestamp_last_day'
LANGUAGE C IMMUTABLE STRICT;


CREATE INTERNAL FUNCTION sys_catalog.LAST_DAY(ORA_DATE)
RETURNS ORA_DATE
as 'select cast(TIMESTAMP_LAST_DAY($1) as "SYS_CATALOG"."ORA_DATE")'
LANGUAGE SQL
IMMUTABLE
STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.LAST_DAY(day timestamptz)
--RETURNS timestamp
--AS $$ select LAST_DAY(cast($1 as timestamp));
--$$ LANGUAGE SQL IMMUTABLE STRICT;

/* bugId#30588: adapter fanwei--date data type compatible with oracle */
CREATE INTERNAL FUNCTION sys_catalog.TIMESTAMP_NEXT_DAY(day ORA_DATE, weekday text)
RETURNS timestamp
AS 'MODULE_PATHNAME','timestamp_next_day'
LANGUAGE C IMMUTABLE STRICT;


CREATE INTERNAL FUNCTION sys_catalog.NEXT_DAY(ORA_DATE, TEXT)
RETURNS ORA_DATE
as 'select cast(TIMESTAMP_NEXT_DAY($1, $2) as "SYS_CATALOG"."ORA_DATE")'
LANGUAGE SQL
IMMUTABLE
STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.NEXT_DAY(day timestamptz, weekday text)
--RETURNS timestamp
--AS $$ select NEXT_DAY(cast($1 as timestamp), weekday);
--$$ LANGUAGE SQL IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.ADD_MONTHS(day date, value numeric)
--RETURNS date
--AS 'MODULE_PATHNAME','date_add_months'
--LANGUAGE C IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.NEXT_DAY(value date, weekday text)
--RETURNS date
--AS 'MODULE_PATHNAME','date_next_day'
--LANGUAGE C IMMUTABLE STRICT;

--CREATE INTERNAL FUNCTION sys_catalog.LAST_DAY(value date)
--RETURNS date
--AS 'MODULE_PATHNAME','date_last_day'
--LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMESUB(head timestamptz, tail timestamptz)
RETURNS float8
AS 'MODULE_PATHNAME', 'timesub'
LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMEZONE(value timestamp)
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamp_localzone'
LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMEZONE(value timestamptz)
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamptz_localzone'
LANGUAGE C IMMUTABLE STRICT;

CREATE INTERNAL FUNCTION sys_catalog.TIMEZONE(value timetz)
RETURNS timetz
AS 'MODULE_PATHNAME','timetz_localzone'
LANGUAGE C IMMUTABLE STRICT;

/* bugId#30588: adapter fanwei--date data type compatible with oracle */
CREATE INTERNAL FUNCTION sys_catalog.MONTHS_BETWEEN(ORA_DATE, ORA_DATE)
 returns numeric STABLE language sql as $$
  select (extract(years from $1)::int * 12 - extract(years from $2)::int * 12)::numeric +
  (extract(month from $1)::int - extract(month from $2)::int)::numeric +
  (extract(day from $1)::int - extract(day from $2)::int)/31::numeric
$$;


--
-- BUG2020113000795 DATEDIFF for MySQL & SQLServer
--

--
-- SQL Server
-- DATEDIFF (flags VARCHAR(10), units VARCHAR(30), start_t TIMESTAMP, end_t TIMESTAMP)
--
CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (flags VARCHAR(10), units VARCHAR(30), start_t TIMESTAMP, end_t TIMESTAMP)
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
     years_diff INT = 0;
   BEGIN
     units = LOWER(units);

     IF units IN ('yy', 'yyyy', 'year', 'mm', 'm', 'month', 'qq', 'q', 'quarter') THEN
       years_diff = DATE_PART('year', end_t) - DATE_PART('year', start_t);

       IF units IN ('yy', 'yyyy', 'year') THEN
         -- SQL Server does not count full years passed (only difference between year parts)
         RETURN years_diff;
       ELSIF units IN ('qq', 'q', 'quarter') THEN
	 -- Quarters_diff equal (month_diff / 3)
         diff = years_diff * 12 + (DATE_PART('month', end_t) - DATE_PART('month', start_t));
         diff = diff / 3;
	 RETURN diff;
       ELSE
         -- If end month is less than start month it will subtracted
         RETURN years_diff * 12 + (DATE_PART('month', end_t) - DATE_PART('month', start_t));
       END IF;
     END IF;

     -- Minus operator returns interval 'DDD days HH:MI:SS'
     diff = end_t::DATE - start_t::DATE;

     IF units IN ('wk', 'ww', 'week') THEN
       diff = diff/7;
       RETURN diff;
     END IF;

     IF units IN ('dd', 'd', 'day', 'dy', 'y', 'dayofyear') THEN
       RETURN diff;
     END IF;

     diff = diff * 24 + DATE_PART('hour', end_t) - DATE_PART('hour', start_t);

     IF units IN ('hh', 'hour') THEN
        RETURN diff;
     END IF;

     diff = diff * 60 + DATE_PART('minute', end_t) - DATE_PART('minute', start_t);

     IF units IN ('mi', 'n', 'minute') THEN
        RETURN diff;
     END IF;

     IF units IN ('ss', 's', 'second') THEN
        diff = diff * 60 + DATE_PART('second', end_t) - DATE_PART('second', start_t);
     ELSIF units IN ('ms', 'millisecond') THEN
        diff = diff * 60 * 1000 + DATE_PART('milliseconds', DATE_TRUNC('millisecond', end_t)) - DATE_PART('milliseconds', DATE_TRUNC('millisecond', start_t));
     ELSIF units IN ('mcs', 'microsecond') THEN
        diff = diff * 60 * 1000000 + DATE_PART('microseconds', DATE_TRUNC('microsecond', end_t)) - DATE_PART('microseconds', DATE_TRUNC('microsecond', start_t));
     ELSIF units IN ('ns', 'nanosecond') THEN
        diff = diff * 60 * 1000000000 + DATE_PART('microseconds', DATE_TRUNC('microsecond', end_t)) - DATE_PART('microseconds', DATE_TRUNC('microsecond', start_t));
     ELSE
	RAISE EXCEPTION 'DATEDIFF function not support for type TIMESTAMP using datepart: %', units;
     END IF;

     RETURN diff;
   END;
   $$ LANGUAGE plsql;

--
-- SQL Server
-- DATEDIFF (flags VARCHAR(10), units VARCHAR(30), start_t TIME, end_t TIME)
--
CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (flags VARCHAR(10), units VARCHAR(30), start_t TIME, end_t TIME)
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
     units = LOWER(units);

     IF units IN ('yy', 'yyyy', 'year', 'qq', 'q', 'quarter', 'mm', 'm', 'month', 'dy', 'y', 'dayofyear', 'dd', 'd', 'day', 'wk', 'ww', 'week') THEN
	RAISE EXCEPTION 'DATEDIFF function not support for type TIME using TIMESTAMP datepart: %', units;
     END IF;

     diff = DATE_PART('hour', end_t) - DATE_PART('hour', start_t);

     IF units IN ('hh', 'hour') THEN
       RETURN diff;
     END IF;

     diff = diff * 60 + DATE_PART('minute', end_t) - DATE_PART('minute', start_t);

     IF units IN ('mi', 'n', 'minute') THEN
        RETURN diff;
     END IF;

     IF units IN ('ss', 's', 'second') THEN
        diff = diff * 60 + DATE_PART('second', end_t) - DATE_PART('second', start_t);
     ELSIF units IN ('ms', 'millisecond') THEN
        diff = diff * 60 * 1000 + DATE_PART('milliseconds', DATE_TRUNC('millisecond', end_t)) - DATE_PART('milliseconds', DATE_TRUNC('millisecond', start_t));
     ELSIF units IN ('mcs', 'microsecond') THEN
        diff = diff * 60 * 1000000 + DATE_PART('microseconds', DATE_TRUNC('microsecond', end_t)) - DATE_PART('microseconds', DATE_TRUNC('microsecond', start_t));
     ELSIF units IN ('ns', 'nanosecond') THEN
        diff = diff * 60 * 1000000000 + DATE_PART('microseconds', DATE_TRUNC('microsecond', end_t)) - DATE_PART('microseconds', DATE_TRUNC('microsecond', start_t));
     ELSE
	RAISE EXCEPTION 'DATEDIFF function not support for type TIME using datepart: %', units;
     END IF;

     RETURN diff;
   END;
   $$ LANGUAGE plsql;

--
-- MySQL DATEDIFF(start_t VARCHAR(64), end_t VARCHAR(64))
--
CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (start_t VARCHAR(64), end_t VARCHAR(64))
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
	diff = "SYS_CATALOG"."DATEDIFF" ('MSSQL', 'day', start_t::TIMESTAMP, end_t::TIMESTAMP);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (start_t TIMESTAMP, end_t TIMESTAMP)
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" ('MSSQL', 'day', start_t, end_t);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (start_t VARCHAR(64), end_t TIMESTAMP)
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" ('MSSQL', 'day', start_t::TIMESTAMP, end_t);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (start_t TIMESTAMP, end_t VARCHAR(64))
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" ('MSSQL', 'day', start_t, end_t::TIMESTAMP);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;


--
-- SQLServer DATEDIFF(units VARCHAR(30), start_t VARCHAR(64), end_t VARCHAR(64))
--
CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (units VARCHAR(30), start_t VARCHAR(64), end_t VARCHAR(64))
     RETURNS INT AS $$
   DECLARE
     pos_a1 INT = 0;
     pos_b1 INT = 0;
     diff INT = 0;
   BEGIN
     -- trim the begin & end spaces
     start_t = TRIM(start_t);
     end_t = TRIM(end_t);

     -- check if format like '10:30:00'
     pos_a1 = STRPOS(start_t, ':');
     pos_b1 = STRPOS(end_t, ':');

     -- check if format like '2020-10-12 10:30:00'
     IF (pos_a1 != 0 AND pos_b1 != 0) THEN
        pos_a1 = STRPOS(start_t, ' ');
        pos_b1 = STRPOS(end_t, ' ');

	-- call function as time
        IF (pos_a1 = 0 AND pos_b1 = 0) THEN
	   diff = "SYS_CATALOG"."DATEDIFF" ('MSSQL', units::VARCHAR, start_t::TIME, end_t::TIME);
           RETURN diff;
        END IF;
     END IF;

     -- call function as timestamp
     diff = "SYS_CATALOG"."DATEDIFF" ('MSSQL', units::VARCHAR, start_t::TIMESTAMP, end_t::TIMESTAMP);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (units VARCHAR(30), start_t TIMESTAMP, end_t TIMESTAMP)
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" (units, start_t::VARCHAR, end_t::VARCHAR);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (units VARCHAR(30), start_t TIME, end_t TIME)
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" (units, start_t::VARCHAR, end_t::VARCHAR);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (units VARCHAR(30), start_t VARCHAR(64), end_t TIMESTAMP)
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" (units, start_t::VARCHAR, end_t::VARCHAR);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (units VARCHAR(30), start_t TIMESTAMP, end_t VARCHAR(64))
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" (units, start_t::VARCHAR, end_t::VARCHAR);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (units VARCHAR(30), start_t VARCHAR(64), end_t TIME)
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" (units, start_t::VARCHAR, end_t::VARCHAR);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

CREATE INTERNAL FUNCTION "SYS_CATALOG"."DATEDIFF" (units VARCHAR(30), start_t TIME, end_t VARCHAR(64))
     RETURNS INT AS $$
   DECLARE
     diff INT = 0;
   BEGIN
        diff = "SYS_CATALOG"."DATEDIFF" (units, start_t::VARCHAR, end_t::VARCHAR);
     RETURN diff;
   END;
   $$ LANGUAGE plsql;

