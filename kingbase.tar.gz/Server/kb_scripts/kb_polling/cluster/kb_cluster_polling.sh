#!/bin/bash

####################################################################################################################                                                                                                                                                 
###                                                                                                                                                                                                                                                                  
### Descipt: this tool help us to make a database cluster poling 
### Author : HM
### Create : 2020-04-28
###
### Usage  :
###        ./kb_polling.sh cluster_vip cluster_port db_user cluster_password db_name
###
####################################################################################################################


echo "This tool help use to make a database polling, must execute in local server"
echo ""

if [ $# -eq 5 ]; then
    cluster_vip=$1
	cluster_port=$2
	db_user=$3
	db_pwrd=$4
	db_name=$5
else
	echo "the parameter is error, please check again !"
	echo "Usage:"
	echo "kb_polling_cluster.sh cluster_host cluster_port db_user db_password db_name"
	echo ""
	exit
fi

#TODO: db_vip was't plain to check
#TODO: cluster role was't plain to check (where is the cluster vip, where is the primary cluster node)

echo "kingbase database polling begin : $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

main_proc_num=$(ps -ef|grep "bin/kingbase"|grep D|wc -l)
if [ $main_proc_num -eq 0 ]; then
	echo "the database is not on live, please check it !!!"
	echo ""
	exit
fi

kingbase_path=$(ps -ef|grep "bin/kingbase"|grep cluster|grep D|awk '{print $8}')
bin_path=${kingbase_path%/*}
server_path=${bin_path%/*}
install_path=${server_path%/*}
db_conn=$(echo $bin_path/ksql -At -h $cluster_vip -p $cluster_port -U $db_user -W $db_pwrd -d $db_name)
db_conn_noAt=$(echo $bin_path/ksql -h $cluster_vip -p $cluster_port -U $db_user -W $db_pwrd -d $db_name)
#echo $db_conn

$db_conn_noAt -c "select now();" > /dev/null 2>&1
if [ $? -ne 0 ] ;then
	echo "the cluster is not on live, please check it !!!"
	echo "cluster connection info is: "
	echo ""$db_conn_noAt
	echo ""
    exit 1
else
    echo "cluster status     : running"
fi

echo ""
echo "local database info:"
echo "database bin_path  :  "$bin_path

data_dir=$(ps -ef|grep "bin/kingbase"|grep cluster|grep D|awk '{print $10}')
if [ $data_dir = "." ]; then
    #echo "can not get data path from main process, now get it from database"
    data_dir=$($db_conn -c "show data_directory;")
fi
echo "database data_dir  :  "$data_dir

db_version=$($db_conn -c "select version()")
echo "database version   :  "$db_version

case_sensitive=$($db_conn -c "show case_sensitive")
echo "database sensitive : " $case_sensitive
echo "DB PORT            : " $cluster_port

main_proc_pid=$(ps -ef|grep kingbase|grep data|grep D|awk '{print $2}')
echo "database main_pid  : " $main_proc_pid
echo ""

echo "1.show cluster info:"
echo "----------------------------------------------------------------------------"
$db_conn_noAt -c "show pool_nodes;"
echo ""
echo "----------------------------------------------------------------------------"

echo "2.show replication stat info:"
echo "----------------------------------------------------------------------------"
$db_conn_noAt -c "select * from sys_stat_replication;"
echo ""
echo "----------------------------------------------------------------------------"

echo "3.show wal gap info:"
echo "----------------------------------------------------------------------------"
$db_conn_noAt -c "select application_name, client_addr, backend_start, backend_xmin, state, sync_state, sent_location, write_location, flush_location, replay_location, 
sys_xlog_location_diff(sent_location, replay_location) send_replay_gap, sys_xlog_location_diff(SYS_CURRENT_XLOG_LOCATION(),replay_location) current_replay_gap from sys_stat_replication;"
echo ""
echo "----------------------------------------------------------------------------"
echo "kingbase cluster polling end : $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

