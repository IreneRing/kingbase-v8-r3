#!/bin/bash

db_file_list=(
install.conf
all_monitor.sh
change_vip.sh
kingbase_checkpoint.sh
kingbase_monitor.sh
kingbase_promote.sh
network_rewind.sh
rebuild_standby.sh
V8R3_cluster_install.sh
es_server
es_client
)

cluster_file_list=(
all_monitor.sh
failover_stream.sh
restartcluster.sh
)

backup_file="sys_backup_ssl.sh"

shell_folder=$(dirname $(readlink -f "$0"))

# path under db directory
db_path=$(dirname ${shell_folder})
db_bin_path=${db_path}/bin
db_es_path=${shell_folder}

# path under cluster directory
cluster_path=$(dirname ${db_path})/kingbasecluster
cluster_bin_path=${cluster_path}/bin
cluster_es_path=${cluster_path}/es_server

update_cluster=1

function check_env()
{
    # can not execute by root
    execute_user=`id -un 2>/dev/null`
    if [ "${execute_user}"x = "root"x ]
    then
        echo "[ERROR] could not execute by root"
        exit 1
    fi

    if [ ${#db_file_list[@]} -le 0 ]
    then
        echo "[ERROR] the db_file_list is NULL"
        exit 1
    fi
    if [ ${#cluster_file_list[@]} -le 0 ]
    then
        echo "[ERROR] the cluster_file_list is NULL"
        exit 1
    fi

    if [ ! -d ${db_bin_path} ]
    then
        echo "[ERROR] The db bin path ${db_bin_path} not exist ... FAILED"
        exit 1
    fi

    if [ ! -d ${cluster_path} ]
    then
        echo "[WARNING] There is no cluster path ${cluster_path}, will not update for cluster"
        update_cluster=0
    elif [ ! -d ${cluster_bin_path} ]
    then
        echo "[WARNING] There is no bin path ${cluster_bin_path}, will not update for cluster"
        update_cluster=0
    elif [ ! -d ${cluster_es_path} ]
    then
        echo "[WARNING] There is no es_server path ${cluster_es_path}, will not update for cluster"
        update_cluster=0
    fi
}

function check_file_list()
{
    local err_flag=0

    echo "[CHECK] check old files in ${db_bin_path} ..."
    for item in ${db_file_list[@]}
    do
        if [ -f ${db_bin_path}/${item} ]
        then
            echo "[INFO] ${db_bin_path}/${item} exist, will rename it"
        fi
    done
    echo "[CHECK] check old files in ${db_bin_path} ... OK"

    echo "[CHECK] check new files in ${db_es_path} ..."
    for item in ${db_file_list[@]}
    do
        if [ -f ${db_es_path}/${item} ]
        then
            echo "[INFO] ${db_es_path}/${item} exist"
        else
            echo "[ERROR] ${db_es_path}/${item} not exist"
            err_flag=1
        fi
    done
    if [ "${backup_file}"x != ""x ]
    then
        if [ -f ${db_bin_path}/${backup_file} ]
        then
            echo "[INFO] ${db_bin_path}/${backup_file} exist"
        else
            echo "[ERROR] ${db_bin_path}/${backup_file} not exist"
            err_flag=1
        fi
    fi
    if [ ${err_flag} -ne 0 ]
    then
        echo "[CHECK] check new files in ${db_es_path} ... FAILED"
        exit 1
    fi
    echo "[CHECK] check new files in ${db_es_path} ... OK"

    if [ ${update_cluster} -eq 1 ]
    then
        echo "[CHECK] check old files in ${cluster_bin_path} ..."
        for item in ${cluster_file_list[@]}
        do
            if [ -f ${cluster_bin_path}/${item} ]
            then
                echo "[INFO] ${cluster_bin_path}/${item} exist, will rename it"
            fi
        done
        echo "[CHECK] check old files in ${cluster_bin_path} ... OK"

        echo "[CHECK] check new files in ${cluster_es_path} ..."
        for item in ${cluster_file_list[@]}
        do
            if [ -f ${cluster_es_path}/${item} ]
            then
                echo "[INFO] ${cluster_es_path}/${item} exist"
            else
                echo "[ERROR] ${cluster_es_path}/${item} not exist"
                err_flag=1
            fi
        done
        if [ ${err_flag} -ne 0 ]
        then
            echo "[CHECK] check new files in ${cluster_es_path} ... FAILED"
            exit 1
        fi
        echo "[CHECK] check new files in ${cluster_es_path} ... OK"
    fi
}

function update_one_file()
{
    local target_file="$1"
    local old_file="$2"
    local new_file="$3"

    if [ "${target_file}"x = ""x ]
    then
        echo "[ERROR] the target_file is NULL, do nothing"
        return 1
    elif [ "${old_file}"x = ""x ]
    then
        echo "[ERROR] the old_file is NULL, do nothing"
        return 1
    elif [ "${new_file}"x = ""x ]
    then
        echo "[ERROR] the new_file is NULL, do nothing"
        return 1
    fi

    if [ -f ${target_file} ]
    then
        if [ -f ${old_file} ]
        then
            rm -f ${target_file}
            if [ $? -eq 0 ]
            then
                echo "[INFO] success to del ${target_file}, the ${old_file} is already exist"
            else
                echo "[ERROR] failed to del ${target_file}, the ${old_file} is already exist"
                return 1
            fi
        else
            mv ${target_file} ${old_file}
            if [ $? -eq 0 ]
            then
                echo "[INFO] success to rename ${target_file} to ${old_file}"
            else
                echo "[ERROR] failed to rename ${target_file} to ${old_file}"
                return 1
            fi
        fi
    fi
    cp -f ${new_file} ${target_file}
    if [ $? -eq 0 ]
    then
        echo "[INFO] success to copy ${new_file} to ${target_file}"
    else
        echo "[ERROR] failed to copy ${new_file} to ${target_file}"
        return 1
    fi
}

function update_file_list()
{
    local err_flag=0
    local target_file=""
    local old_file=""
    local new_file=""

    echo "[UPDATE] update files in ${db_path} ..."
    for item in ${db_file_list[@]}
    do
        target_file="${db_bin_path}/${item}"
        old_file="${db_bin_path}/OLD_${item}"
        new_file="${db_es_path}/${item}"

        update_one_file ${target_file} ${old_file} ${new_file}
        [ $? -ne 0 ] && err_flag=1 && break
    done
    if [ $err_flag -eq 0 -a "${backup_file}"x != ""x ]
    then
        target_file="${db_bin_path}/sys_backup.sh"
        old_file="${db_bin_path}/OLD_sys_backup.sh"
        new_file="${db_bin_path}/${backup_file}"

        update_one_file ${target_file} ${old_file} ${new_file}
        [ $? -ne 0 ] && err_flag=1
    fi
    if [ $err_flag -ne 0 ]
    then
        echo "[UPDATE] update files in ${db_path} ... FAILED"
        exit 1
    fi
    echo "[UPDATE] update files in ${db_path} ... OK"

    if [ ${update_cluster} -eq 1 ]
    then
        echo "[UPDATE] update files in ${cluster_path} ..."
        for item in ${cluster_file_list[@]}
        do
            target_file="${cluster_bin_path}/${item}"
            old_file="${cluster_bin_path}/OLD_${item}"
            new_file="${cluster_es_path}/${item}"

            update_one_file ${target_file} ${old_file} ${new_file}
            [ $? -ne 0 ] && err_flag=1 && break
        done
        if [ $err_flag -ne 0 ]
        then
            echo "[UPDATE] update files in ${cluster_path} ... FAILED"
            exit 1
        fi
        echo "[UPDATE] update files in ${cluster_path} ... OK"
    fi
    echo "[UPDATE] DONE"
}

# mian()
check_env
check_file_list
update_file_list

exit 0