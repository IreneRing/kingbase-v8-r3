#!/bin/bash
#del VIP

<<COMMENT
#LOOK HERE!!
#Need manually add DEV NAME, only if all network cards are not same name
#like DEV=eth0
DEV=""
#default sbin path
CMD_IP_PATH="/sbin"
CMD_ARPING_PATH="/sbin"
COMMENT

SHELL_FOLDER=$(dirname $(readlink -f "$0"))
CfgFile="${SHELL_FOLDER}/../etc/HAmodule.conf"

if [ ! -f ${CfgFile} ]
then
    echo "change_vip.sh: No \"$CfgFile\" files!" >&2
    exit 1
fi

#read the configuration file HAmodule.conf
function LoadCfg()
{
    while read cfg
    do
        # del comment in cfg
        param=${cfg%%#*}
        paramName=${param%%=*}
        paramValue=${param#*=}

        if [ -z "$paramName" ] ; then
            continue
        elif [ -z "$paramValue" ]; then
            continue
        fi
        eval $paramName=$paramValue
    done < $CfgFile
}

#Load config file
LoadCfg

OPRATE=$1
TARGET_VIP=$2
IS_FIRST_ADD=$3

#the function of error handing
check_err_result()
{
    if [ $1 != 0 ]
    then
        echo "`date +'%Y-%m-%d %H:%M:%S'` error code:$1"
        exit $1
    fi
}

if [ "$TARGET_VIP"x = ""x ]
then
    echo "no pass the vip, details set vip[$TARGET_VIP], return"
    exit 1
fi

if [ "$DEV"x = ""x ]
then
    echo "the DEV is null, details set dev[$DEV], return"
    exit 1
fi

#determine execute add or del vip by passing parameter
if [ "$OPRATE"x = "del"x -a "$DEV"x != ""x ]
then
    echo "DEL VIP NOW AT `date +'%Y-%m-%d %H:%M:%S'` ON $DEV"
    ip_exist=`${CMD_IP_PATH}/ip addr | grep -w "$TARGET_VIP" | wc -l; echo ";" ${PIPESTATUS[*]}`
	result_of_ip_exist=`echo $ip_exist |awk -F ';' '{print $1}'|awk '{print $1}'`
	cmd_ipaddr=`echo $ip_exist |awk -F ';' '{print $2}' |awk '{print $1}'`
	cmd_grep=`echo $ip_exist |awk -F ';' '{print $2}' |awk '{print $2}'`
	cmd_wc=`echo $ip_exist |awk -F ';' '{print $2}' |awk '{print $3}'`
    check_err_result $cmd_ipaddr
	check_err_result $cmd_wc
    if [ $result_of_ip_exist -eq 0 ]
    then
        echo "No VIP on my dev, nothing to do."
        exit 0;
    fi

    echo "execute: [${CMD_IP_PATH}/ip addr $OPRATE $TARGET_VIP dev $DEV]"
    ${CMD_IP_PATH}/ip addr $OPRATE $TARGET_VIP dev $DEV 2>/dev/null
    check_err_result $?

    echo "Oprate del ip cmd end."
elif [ "$OPRATE"x = "add"x -a "$DEV"x != ""x ]
then
    if [ "$IS_FIRST_ADD"x != ""x ]
    then
        master_node=`ls ${KB_DATA_PATH}/recovery.conf 2>/dev/null |wc -l; echo ";" ${PIPESTATUS[*]}`
		result_of_master_node=`echo $master_node |awk -F ';' '{print $1}'|awk '{print $1}'`
		cmd_ls=`echo $master_node |awk -F ';' '{print $2}' |awk '{print $1}'`
		cmd_wc=`echo $master_node |awk -F ';' '{print $2}' |awk '{print $2}'`
		check_err_result $cmd_wc
        if [ "$result_of_master_node" -eq 1 ]
        then
            exit 0
        fi
    fi

    local_ip_num=`${CMD_IP_PATH}/ip addr | grep -w "$KB_LOCALHOST_IP" | wc -l;echo ";" ${PIPESTATUS[*]}`
    result_of_local_ip_num=`echo $local_ip_num |awk -F ';' '{print $1}'|awk '{print $1}'`

    if [ "${result_of_local_ip_num}"x = "0"x ]; then
        echo "${KB_LOCALHOST_IP} is not exists, do not add the vip."
        exit 1
    fi

    echo ADD VIP NOW AT `date +'%Y-%m-%d %H:%M:%S'` ON $DEV
    echo "execute: [${CMD_IP_PATH}/ip addr add $TARGET_VIP dev $DEV label ${DEV}:2]"
    ${CMD_IP_PATH}/ip addr add $TARGET_VIP dev $DEV label ${DEV}:2 2>&1
    check_err_result $?

    echo "execute: ${CMD_ARPING_PATH}/arping -U ${TARGET_VIP%%/*} -I $DEV -w 1"
    ${CMD_ARPING_PATH}/arping -U ${TARGET_VIP%%/*} -I $DEV -w 1 -c 1 2>/dev/null
else
    echo "oprate vip failed, details vip[$TARGET_VIP], dev[$DEV], oprate[$OPRATE]"
    exit 1
fi
