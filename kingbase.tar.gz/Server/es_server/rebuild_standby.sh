#!/bin/bash

function LoadCfg()
{
    SHELL_FOLDER=$(dirname $(readlink -f "$0"))
    CfgFile="${SHELL_FOLDER}/../etc/HAmodule.conf"
    while read cfg;do
    param=${cfg%%#*}
        paramName=${param%%=*}
        paramValue=${param#*=}
    if [ -z "${paramName}" ] ; then
        continue
    elif [ -z "${paramValue}" ]; then
        continue
    fi
    eval ${paramName}=${paramValue}
    done < ${CfgFile}

    [ "$ES_PORT"x = ""x ] && ES_PORT=8890
}

function check_all_rebuild_stanby()
{
    check_excute_user
    check_is_in_cluster
    LoadCfg
    check_is_standby
    check_is_up
    check_port_is_occupied
    check_network_rewind
}

function check_excute_user()
{
    SHELL_FOLDER=$(dirname $(readlink -f "$0"))
    local file_path="${SHELL_FOLDER}/rebuild_standby.sh"
    local current_user=`id -un`
    local file_owner=`ls -l ${file_path} | awk '{print $3}'`
    if [ "${current_user}"x != "${file_owner}"x ]
    then
        echo "[`date`] [ERROR] can not execute by user \"${current_user}\""
        exit 1
    else
        echo "[`date`] [INFO] current user can rebuild standby db"
    fi
}

function check_is_in_cluster()
{
    SHELL_FOLDER=$(dirname $(readlink -f "$0"))
    local db_etc_path=$SHELL_FOLDER/../etc
    if [ ! -f $db_etc_path/HAmodule.conf ]
    then
        echo "[`date`] [ERROR] $db_etc_path/HAmodule.conf does not exist, it may not be a cluster environment, please check"
        exit 1
    fi
    if [ ! -f $db_etc_path/kingbase.conf ]
    then
        echo "[`date`] [ERROR] $db_etc_path/kingbase.conf does not exist, it may not be a cluster environment, please check"
        exit 1
    fi
    if [ ! -f $db_etc_path/recovery.done ]
    then
        echo "[`date`] [ERROR] $db_etc_path/recovery.done does not exist, it may not be a cluster environment, please check"
        exit 1
    fi
    echo "[`date`] [INFO] the current environment is cluster environment, can rebuild standby db"
}

function check_is_standby()
{
    KB_REAL_PASS=`echo $KB_PASS | base64 -d 2>/dev/null`
    primary_in_cluster=`$KB_PATH/ksql -Atq "host=$KB_POOL_VIP port=$KB_POOL_PORT user=$KB_USER password=$KB_REAL_PASS dbname=$KB_DATANAME connect_timeout=10" -c "show pool_nodes;"|grep primary |awk -F '|' '{print $2}' | tr -d ' '`
    if [ $? -ne 0 -o "$primary_in_cluster"x = ""x ]
    then
        echo "[`date`] [ERROR] there is no primary in cluster, can not rebuilt"
        exit 1
    fi
    local IMPRI_FLAG=`echo $primary_in_cluster | grep -w $KB_LOCALHOST_IP | wc -l`
    if [ $IMPRI_FLAG -eq 1 ]
    then
        echo "[`date`] [ERROR] the current db is primary in cluster, can not rebuilt"
        exit 1
    else
        echo "[`date`] [INFO] the current db is not primary in cluster, can rebuild standby db"
    fi
}

function check_is_up()
{
    if [ -f $KB_DATA_PATH/kingbase.pid ]
    then
        local kingbase_pid=`cat ${KB_DATA_PATH}/kingbase.pid |head -n 1`
        local kingbase_exist=`ps -ef | grep -w $kingbase_pid | grep -v grep | wc -l`
        if [ $kingbase_exist -ne 0 ]
        then
            echo "[`date`] [ERROR] the current db is started, can not rebuilt"
            exit 1
        else
            echo "[`date`] [INFO] the current db is stoped, can rebuilt"
        fi
    fi
}

function check_port_is_occupied()
{
    local port_is_occupied=`netstat -an | grep -w $KB_PORT |grep -w "LISTEN"  |wc -l`
    if [ $port_is_occupied -ne 0 ]
    then
        echo "[`date`] [ERROR] the current db port is occupied, can not rebuilt"
        exit 1
    else
        echo "[`date`] [INFO] the current db port is not occupied, can rebuilt"
    fi
}

function check_network_rewind()
{
    echo "[`date`] [INFO] stop the crontab of network_rewind.sh"
    local realist=`$KB_PATH/es_client -o StrictHostKeyChecking=no -o ConnectTimeout=$CONNECTTIMEOUT -l root -T $KB_LOCALHOST_IP "cat /etc/cron.d/KINGBASECRON | grep -wFn \"*/1 * * * * $KB_EXECUTE_SYS_USER  ${KB_PATH}/network_rewind.sh\""`
    local linenum=`echo "$realist" |awk -F':' '{print $1}'`
    
    $KB_PATH/es_client -o StrictHostKeyChecking=no -o ConnectTimeout=$CONNECTTIMEOUT -p $ES_PORT -l root -T $KB_LOCALHOST_IP "sed -i \"${linenum}s/^/#/\" /etc/cron.d/KINGBASECRON"

    network_rewind_is_execute=`ps -ef|grep -v grep|grep -w "network_rewind.sh" |wc -l`
    if [ $network_rewind_is_execute -eq 0 ]
    then
        echo "[`date`] [INFO] no network_rewind.sh is executing"
    else
        echo "[`date`] [ERROR] network_rewind.sh is executing, please wait for it to exit"
        exit 1
    fi
}

function do_rebuilt_standby()
{
    echo "[`date`] [INFO] start do rebuild standby db"

    KB_DATA_BAK_PATH=${KB_DATA_PATH}_`date +%N`
    if [ -e $KB_DATA_PATH ]
    then
        mv $KB_DATA_PATH $KB_DATA_BAK_PATH
        if [ $? -eq 0 ]
        then
            echo "[`date`] [INFO] mv $KB_DATA_PATH to $KB_DATA_BAK_PATH ... OK"
        else
            echo "[`date`] [ERROR] mv $KB_DATA_PATH to $KB_DATA_BAK_PATH failed, please check"
            exit 1
        fi
    fi

    replica_user=`grep "^primary_conninfo" ${KB_ETC_PATH}/recovery.done | sed "s/\(.*\)\(user=[^ ']*\)\(.*$\)/\2/g" |awk -F '=' '{print $2}'`
    replica_password=`grep "^primary_conninfo" ${KB_ETC_PATH}/recovery.done | sed "s/\(.*\)\(password=[^ ']*\)\(.*$\)/\2/g" |awk -F '=' '{print $2}'`
    replica_real_password=`echo $replica_password | base64 -d 2>/dev/null`
    $KB_PATH/sys_basebackup -h $primary_in_cluster -U $replica_user -W $replica_real_password -p $KB_PORT -F p -X stream -D $KB_DATA_PATH
    if [ $? -eq 0 ]
    then
        echo "[`date`] [INFO] $KB_PATH/sys_basebackup -h $primary_in_cluster -U $replica_user -W $replica_real_password -p $KB_PORT -F p -X stream -D $KB_DATA_PATH ... OK"
    else
        echo "[`date`] [ERROR] $KB_PATH/sys_basebackup -h $primary_in_cluster -U $replica_user -W $replica_real_password -p $KB_PORT -F p -X stream -D $KB_DATA_PATH failed, please check"
        exit 1
    fi

    [ ! -f $KB_DATA_PATH/kingbase.auto.conf ] || rm -f $KB_DATA_PATH/kingbase.auto.conf
    if [ $? -eq 0 ]
    then
        echo "[`date`] [INFO] rm -f $KB_DATA_PATH/kingbase.auto.conf ... OK"
    else
        echo "[`date`] [ERROR] rm -f $KB_DATA_PATH/kingbase.auto.conf failed, please check"
        exit 1
    fi
    [ ! -f $KB_DATA_PATH/kingbase.conf ] || rm -f $KB_DATA_PATH/kingbase.conf
    if [ $? -eq 0 ]
    then
        echo "[`date`] [INFO] rm -f $KB_DATA_PATH/kingbase.conf ... OK"
    else
        echo "[`date`] [ERROR] rm -f $KB_DATA_PATH/kingbase.conf failed, please check"
        exit 1
    fi
    [ ! -f $KB_DATA_PATH/recovery.conf ] || rm -f $KB_DATA_PATH/recovery.conf
    if [ $? -eq 0 ]
    then
        echo "[`date`] [INFO] rm -f $KB_DATA_PATH/recovery.conf ... OK"
    else
        echo "[`date`] [ERROR] rm -f $KB_DATA_PATH/recovery.conf failed, please check"
        exit 1
    fi
    cp ${KB_ETC_PATH}/recovery.done $KB_DATA_PATH/recovery.conf
    if [ $? -eq 0 ]
    then
        echo "[`date`] [INFO] cp ${KB_ETC_PATH}/recovery.done $KB_DATA_PATH/recovery.conf ... OK"
    else
        echo "[`date`] [ERROR] cp ${KB_ETC_PATH}/recovery.done $KB_DATA_PATH/recovery.conf failed, please check"
        exit 1
    fi
    sed -i "s#[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}#${primary_in_cluster}#g" $KB_DATA_PATH/recovery.conf
    if [ $? -eq 0 ]
    then
        echo "[`date`] [INFO] use 'sed -i' to set the primary host to \"${primary_in_cluster}\" in $KB_DATA_PATH/recovery.conf ... OK"
    else
        echo "[`date`] [ERROR] use 'sed -i' to set the primary host to \"${primary_in_cluster}\" in $KB_DATA_PATH/recovery.conf failed, please check"
        exit 1
    fi
    cp ${KB_ETC_PATH}/kingbase.conf $KB_DATA_PATH/kingbase.conf
    if [ $? -eq 0 ]
    then
        echo "[`date`] [INFO] cp ${KB_ETC_PATH}/kingbase.conf $KB_DATA_PATH/kingbase.conf ... OK"
    else
        echo "[`date`] [ERROR] cp ${KB_ETC_PATH}/kingbase.conf $KB_DATA_PATH/kingbase.conf failed, please check"
        exit 1
    fi

    $KB_PATH/sys_ctl -w -t 90 -D $KB_DATA_PATH start >/dev/null 2>&1
    if [ $? -eq 0 ]
    then
        echo "[`date`] [INFO] $KB_PATH/sys_ctl -w -t 90 -D $KB_DATA_PATH start ... OK"
    else
        echo "[`date`] [ERROR] $KB_PATH/sys_ctl -w -t 90 -D $KB_DATA_PATH start failed, please check"
        exit 1
    fi

    for node_name in ${ALL_NODE_NAME[@]}
    do
        $KB_PATH/ksql -Atq "host=$KB_LOCALHOST_IP port=$KB_PORT user=$KB_USER password=$KB_REAL_PASS dbname=$KB_DATANAME connect_timeout=10" -c "select sys_create_physical_replication_slot('slot_$node_name');"
        if [ $? -eq 0 ]
        then
            echo "[`date`] [INFO] $KB_PATH/ksql -Atq \"host=$KB_LOCALHOST_IP port=$KB_PORT user=$KB_USER password=$KB_REAL_PASS dbname=$KB_DATANAME connect_timeout=10\" -c \"select sys_create_physical_replication_slot('slot_$node_name');\" ... OK"
        else
            echo "[`date`] [ERROR] $KB_PATH/ksql -Atq \"host=$KB_LOCALHOST_IP port=$KB_PORT user=$KB_USER password=$KB_REAL_PASS dbname=$KB_DATANAME connect_timeout=10\" -c \"select sys_create_physical_replication_slot('slot_$node_name');\", please check"
            exit 1
        fi
    done

    echo "[`date`] [INFO] execute network_rewind.sh add db to cluster"
    $KB_PATH/network_rewind.sh

    echo "[`date`] [INFO] start crontab of network_rewind.sh"
    $KB_PATH/es_client -o StrictHostKeyChecking=no -o ConnectTimeout=$CONNECTTIMEOUT -p $ES_PORT -l root -T $KB_LOCALHOST_IP "$KB_PATH/all_monitor.sh start dbcrond 2>&1"
}

function check_cluster_status()
{
    echo "[`date`] [INFO] show pool_nodes:"
    $KB_PATH/ksql "host=$KB_POOL_VIP port=$KB_POOL_PORT user=$KB_USER password=$KB_REAL_PASS dbname=$KB_DATANAME connect_timeout=10" -c "show pool_nodes;"
    echo "[`date`] [INFO] select * from sys_stat_replication;"
    $KB_PATH/ksql "host=$primary_in_cluster port=$KB_PORT user=$KB_USER password=$KB_REAL_PASS dbname=$KB_DATANAME connect_timeout=10" -c "select * from sys_stat_replication;"
    echo "[`date`] [INFO] select * from sys_replication_slots;"
    $KB_PATH/ksql "host=$KB_LOCALHOST_IP port=$KB_PORT user=$KB_USER password=$KB_REAL_PASS dbname=$KB_DATANAME connect_timeout=10" -c "select * from sys_replication_slots;"
}

check_all_rebuild_stanby

do_rebuilt_standby

check_cluster_status
